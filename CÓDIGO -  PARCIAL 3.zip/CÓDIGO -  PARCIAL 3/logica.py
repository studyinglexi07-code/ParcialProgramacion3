import almacenamiento


def buscar(codigo):
    for inspeccion in almacenamiento.leer_inspecciones():
        if inspeccion["codigo"].lower() == codigo.lower():
            return inspeccion
    return None


def registrar(datos):
    if not datos["codigo"].strip() or buscar(datos["codigo"]) is not None:
        return False
    registros = almacenamiento.leer_inspecciones()
    registros.append(datos)
    almacenamiento.guardar_inspecciones(registros)
    return True


def listar():
    return almacenamiento.leer_inspecciones()


def modificar(codigo, datos):
    registros = listar()
    for registro in registros:
        if registro["codigo"].lower() == codigo.lower():
            registro.update(datos)
            registro["codigo"] = codigo
            almacenamiento.guardar_inspecciones(registros)
            return True
    return False


def agregar_muestra(datos):
    if buscar(datos["inspeccion"]) is None:
        return False
    muestras = almacenamiento.leer_muestras()
    muestras.append(datos)
    almacenamiento.guardar_muestras(muestras)
    return True


def muestras_de(codigo):
    return [m for m in almacenamiento.leer_muestras() if m["inspeccion"].lower() == codigo.lower()]
