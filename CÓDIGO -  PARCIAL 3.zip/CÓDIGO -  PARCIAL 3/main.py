import almacenamiento
import presentacion


def main():
    almacenamiento.preparar_archivos()
    opcion = ""
    while opcion != "7":
        print("\n=== INVENTARIO FORESTAL NACIONAL ===")
        print("1. Registrar inspección")
        print("2. Consultar inspección")
        print("3. Mostrar todas las inspecciones")
        print("4. Modificar inspección")
        print("5. Consultar conteos de árboles")
        print("6. Consultar muestras forestales")
        print("7. Salir")
        opcion = input("Elija una opción: ").strip()
        if opcion == "1":
            presentacion.registrar()
        elif opcion == "2":
            presentacion.consultar()
        elif opcion == "3":
            presentacion.listar()
        elif opcion == "4":
            presentacion.modificar()
        elif opcion == "5":
            presentacion.conteos()
        elif opcion == "6":
            presentacion.mostrar_muestras()
        elif opcion == "7":
            print("Programa finalizado.")
        else:
            print("Opción no válida. Intente nuevamente.")


if __name__ == "__main__":
    main()
