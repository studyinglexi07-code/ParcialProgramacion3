from pathlib import Path

CARPETA = Path(__file__).resolve().parent.parent / "03_datos"
INSPECCIONES = CARPETA / "inspecciones.txt"
MUESTRAS = CARPETA / "muestras.txt"


def preparar_archivos():
    CARPETA.mkdir(exist_ok=True)
    for ruta in [INSPECCIONES, MUESTRAS]:
        ruta.touch(exist_ok=True)


def leer(ruta, campos):
    preparar_archivos()
    registros = []
    with open(ruta, "r", encoding="utf-8") as archivo:
        for linea in archivo:
            valores = linea.rstrip("\n").split("|")
            if len(valores) == len(campos):
                registros.append(dict(zip(campos, valores)))
    return registros


def guardar(ruta, registros, campos):
    preparar_archivos()
    with open(ruta, "w", encoding="utf-8") as archivo:
        for registro in registros:
            archivo.write("|".join(str(registro[campo]) for campo in campos) + "\n")


CAMPOS_INSPECCION = ["codigo", "fecha", "municipio", "departamento", "conglomerado", "ubicacion", "brigada", "responsable", "fustales", "latizales", "brinzales"]
CAMPOS_MUESTRA = ["inspeccion", "codigo", "nombre_comun", "nombre_cientifico", "uso"]


def leer_inspecciones():
    return leer(INSPECCIONES, CAMPOS_INSPECCION)


def guardar_inspecciones(registros):
    guardar(INSPECCIONES, registros, CAMPOS_INSPECCION)


def leer_muestras():
    return leer(MUESTRAS, CAMPOS_MUESTRA)


def guardar_muestras(registros):
    guardar(MUESTRAS, registros, CAMPOS_MUESTRA)
