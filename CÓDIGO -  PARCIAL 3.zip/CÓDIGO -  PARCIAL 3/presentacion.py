import logica


def texto(mensaje):
    while True:
        valor = input(mensaje).strip()
        if valor and "|" not in valor:
            return valor
        print("Escriba un dato no vacío y sin el símbolo |.")


def cantidad(mensaje):
    while True:
        valor = input(mensaje).strip()
        if valor.isdigit():
            return valor
        print("Ingrese un número entero igual o mayor que cero.")


def pedir_datos(codigo=None):
    if codigo is None:
        codigo = texto("Código de inspección: ")
    return {
        "codigo": codigo,
        "fecha": texto("Fecha (DD/MM/AAAA): "),
        "municipio": texto("Municipio: "),
        "departamento": texto("Departamento: "),
        "conglomerado": texto("Código del conglomerado: "),
        "ubicacion": texto("Ubicación: "),
        "brigada": texto("Código de brigada: "),
        "responsable": texto("Responsable: "),
        "fustales": cantidad("Cantidad de fustales: "),
        "latizales": cantidad("Cantidad de latizales: "),
        "brinzales": cantidad("Cantidad de brinzales: ")
    }


def mostrar(dato):
    for clave, valor in dato.items():
        print(clave.replace("_", " ").capitalize() + ":", valor)


def registrar():
    codigo = texto("Código de inspección: ")
    while logica.buscar(codigo) is not None:
        print("Ese código ya existe. Ingrese otro.")
        codigo = texto("Código de inspección: ")
    datos = pedir_datos(codigo)
    logica.registrar(datos)
    print("Inspección registrada correctamente.")
    while input("¿Agregar una muestra? (s/n): ").strip().lower() == "s":
        muestra = {
            "inspeccion": codigo,
            "codigo": texto("Código de muestra: "),
            "nombre_comun": texto("Nombre común: "),
            "nombre_cientifico": texto("Nombre científico: "),
            "uso": texto("Uso: ")
        }
        logica.agregar_muestra(muestra)
        print("Muestra guardada.")


def consultar():
    codigo = texto("Código de inspección: ")
    dato = logica.buscar(codigo)
    if dato is None:
        print("Inspección no encontrada.")
    else:
        mostrar(dato)
        mostrar_muestras(codigo)


def listar():
    registros = logica.listar()
    if not registros:
        print("Todavía no hay inspecciones registradas.")
    for dato in registros:
        print("----------------")
        mostrar(dato)


def modificar():
    codigo = texto("Código de inspección a modificar: ")
    actual = logica.buscar(codigo)
    if actual is None:
        print("Inspección no encontrada.")
        return
    print("Datos actuales:")
    mostrar(actual)
    print("Ingrese todos los datos actualizados (el código se conserva).")
    nuevos = pedir_datos(actual["codigo"])
    logica.modificar(actual["codigo"], nuevos)
    print("Inspección modificada.")


def conteos():
    codigo = texto("Código de inspección: ")
    dato = logica.buscar(codigo)
    if dato is None:
        print("Inspección no encontrada.")
    else:
        for campo in ["fustales", "latizales", "brinzales"]:
            print(campo.capitalize() + ":", dato[campo])
        total = sum(int(dato[campo]) for campo in ["fustales", "latizales", "brinzales"])
        print("Total:", total)


def mostrar_muestras(codigo=None):
    if codigo is None:
        codigo = texto("Código de inspección: ")
    if logica.buscar(codigo) is None:
        print("Inspección no encontrada.")
        return
    muestras = logica.muestras_de(codigo)
    if not muestras:
        print("No hay muestras registradas.")
    for muestra in muestras:
        print("----------------")
        mostrar(muestra)
